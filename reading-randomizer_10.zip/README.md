# Reading Randomizer

Your daily reading ritual — pick a book, open a page, begin.

## Files

```
reading-randomizer/
├── index.html       ← app shell and HTML
├── style.css        ← all styles (light + dark mode)
├── script.js        ← all logic, book data, localStorage
├── manifest.json    ← PWA manifest
├── sw.js            ← service worker (offline support)
├── netlify.toml     ← Netlify headers and cache config
├── icons/           ← ADD YOUR ICONS HERE (see below)
│   ├── icon-192.png
│   └── icon-512.png
└── README.md
```

## Deploy to Netlify (3 steps)

1. Go to [netlify.com](https://netlify.com) and log in
2. Drag the entire `reading-randomizer` folder onto the Netlify dashboard
3. Done — your app is live at a Netlify URL

Or connect via GitHub:
1. Push this folder to a GitHub repo
2. In Netlify: New site → Import from Git → select your repo
3. Build command: leave blank. Publish directory: `.`
4. Deploy site

## Add App Icons

Create two PNG icons and place them in an `icons/` folder:
- `icons/icon-192.png` — 192×192 px
- `icons/icon-512.png` — 512×512 px

Free tools: [favicon.io](https://favicon.io) or [realfavicongenerator.net](https://realfavicongenerator.net)

The app works fine without icons — they just power the PWA install prompt and home screen icon.

## Install as a PWA

Once hosted on HTTPS (Netlify does this automatically):
- **iOS**: Open in Safari → Share → Add to Home Screen
- **Android/Chrome**: Open → browser menu → Add to Home Screen (or install prompt appears automatically)

## localStorage keys

All data is stored under `reading_randomizer_v2` in the browser's localStorage.
Clearing site data in your browser settings will reset streaks and the reading log.

## Adding books

In `script.js`, add entries to the `BOOKS` array:

```js
{
  title:    'Book Title',
  author:   'Author Name',
  category: 'Mindset / Personal Growth',   // must match a category pill
  pages:    300,
  moods:    ['motivation', 'grounding'],    // from the mood pill list
},
```

Available categories:
- Recovery / Sobriety
- Spiritual / Reflection
- Mindset / Personal Growth
- Money / Life Stewardship
- Symbolic / Story-Based Inspiration

Available moods:
- grounding
- motivation
- spiritual reset
- practical sobriety help
- creative spark
- money focus
